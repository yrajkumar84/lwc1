import {
    LightningElement,
    api
} from 'lwc';

export default class MassCustomUpdateFilterChild extends LightningElement {
    @api fieldName;
    @api filterOperator;
    @api filterValue;
}