import { LightningElement, api, track } from "lwc";
const DELAY = 300;
export default class MassCustomPagination extends LightningElement {
	@api recordsperpage;

	@track recordstopaginate;
	@track recordsToDisplay;
	@track totalRecords;
	@track pageNo;
	@track totalPages;
	@track startRecord;
	@track endRecord;
	@track isLoading = false;

	@api set paginaterecords(value) {
		this.recordstopaginate = [];
		this.recordstopaginate = value;
		this.setRecordsToDisplay();
	}

	get paginaterecords() {
		return this.recordstopaginate;
	}

	connectedCallback() {
		if (this.recordstopaginate) {
			this.setRecordsToDisplay();
		}
	}

	setRecordsToDisplay() {
		this.totalRecords = this.recordstopaginate.length;
		if (parseInt(this.totalRecords) > 0) {
			this.pageNo = 1;
			this.totalPages = Math.ceil(this.totalRecords / parseInt(this.recordsperpage));
			this.preparePagination();
		} else {
			this.handleNoRecords();
		}
	}

	handleNoRecords() {
		this.isLoading = true;
		this.pageNo = 0;
		this.totalPages = 0;
		this.startRecord = 0;
		this.endRecord = 0;
		this.recordsToDisplay = [];
		const event = new CustomEvent("pagination", {
			detail: {
				recordsToShow: this.recordsToDisplay
			}
		});
		this.dispatchEvent(event);
		this.template.querySelectorAll("lightning-button").forEach((element) => {
			element.disabled = true;
		});
		this.isLoading = false;
	}

	preparePagination() {
		this.isLoading = true;
		let begin = (this.pageNo - 1) * parseInt(this.recordsperpage);
		let end = parseInt(begin) + parseInt(this.recordsperpage);
		this.recordsToDisplay = this.recordstopaginate.slice(begin, end);
		this.startRecord = begin + parseInt(1);
		this.endRecord = end > this.totalRecords ? this.totalRecords : end;
		//fire event for parent
		const event = new CustomEvent("pagination", {
			detail: {
				recordsToShow: this.recordsToDisplay
			}
		});
		this.dispatchEvent(event);
		window.clearTimeout(this.delayTimeout);
		this.delayTimeout = setTimeout(() => {
			this.checkButtons();
		}, DELAY);
	}

	checkButtons() {
		let buttons = this.template.querySelectorAll("lightning-button");
		buttons.forEach((element) => {
			if (element.label === "First" || element.label === "Previous") {
				element.disabled = this.pageNo === 1 ? true : false;
			}
			if (element.label === "Next" || element.label === "Last") {
				element.disabled = this.pageNo === this.totalPages ? true : false;
			}
		});
		this.isLoading = false;
	}

	handleFirst() {
		this.pageNo = 1;
		this.preparePagination();
	}

	handleNext() {
		this.pageNo += 1;
		this.preparePagination();
	}

	handlePrevious() {
		this.pageNo -= 1;
		this.preparePagination();
	}

	handleLast() {
		this.pageNo = this.totalPages;
		this.preparePagination();
	}

	handleClick(event) {
		let label = event.target.label;
		if (label === "First") {
			this.handleFirst();
		} else if (label === "Next") {
			this.handleNext();
		} else if (label === "Last") {
			this.handleLast();
		} else if (label === "Previous") {
			this.handlePrevious();
		}
	}
}