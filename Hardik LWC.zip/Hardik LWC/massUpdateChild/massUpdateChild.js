/**
 * Created by ekta.thakkar on 8/7/2020.
 */

import { LightningElement, api, track } from "lwc";
import { NavigationMixin } from "lightning/navigation";

export default class MassUpdateChild extends NavigationMixin(LightningElement) {
	@api record;
	@api field;
	@api type;
	@track value;
	@track isText = false;
	@track isTextarea = false;
	@track isRichTextarea = false;
	@track isJavascript = false;
	@track isDate = false;
	@track isPicklist = false;
	@track isMultiSelect = false;
	@track isNumber = false;
	@track isRecordLink = false;
	@track isFormula = false;
	@track isCurrency = false;
	@track isError;
	@track isOutput = false;
	@track isOutputText = false;
	@track isLookup = false;
	@track isHyperlink = false;
	@track isOutputLookup = false;
	@track isCheckBox = false;
	@track options = [];
	@api country = "";
	@api objectName;
	@api isUpdate;
	@api redirectField;
	@api lookupField;
	@api fields;
	@track _fields = [];
	@api drtypepicklistfields;
	@api showCreateNewLookup;
	@api showHoverIcon;
	@api prevnextsteps = [];
	@api isdisabled;
	@api timeoutId;
	@track updatedvalue;
	@track regex = false;
	@track textAreaStyle = false;
	@track textAreaNextStepStyle = false;
	@track backgroundStyle;
	@track showPicklist;
	@api isSiteRiskSnapshot = false;

	connectedCallback() {
		console.log(this.field + "--->" + this.isdisabled);
		if(this.objectName == 'Site_Risk_Snapshot_Record__c') {
			this.isSiteRiskSnapshot = true;
		}
		if (this.fields !== undefined) {
			this._fields = this.fields.split(",");
		}
		// console.log(field,type,record);
		this.value = this.record[this.field];
		//console.log(this.type);
		//console.log(this.field);
		if (this.type === "Text") {
			if (this.field === "SR_Hyperlink__c") {
				this.isHyperlink = true;
			} else {
				this.isText = true;
			}
		} else if (this.type === "Javascript") {
			this.isJavascript = true;
			if (this.field === "Country__c") {
				//console.log('Child',this.record.Id,this.record.countryOptions);
				this.options = JSON.parse(this.record.countryOptions);
				this.value = this.record[this.field];
			} else {
				if (this.record.hasOwnProperty("stateOptions") && this.record.stateOptions !== "") {
					this.options = JSON.parse(this.record.stateOptions);
					this.value = this.record[this.field];
				}
			}
		} else if (this.type === "Date") {
			this.isDate = true;
		} else if (this.type === "Output") {
			this.isOutput = true;
		} else if (this.type === "Number") {
			this.isNumber = true;
		} else if (this.type === "Text Area") {
			if (this.field === "SR_Next_Steps__c") {
				this.textAreaNextStepStyle = true;
				this.isTextarea = true;
			} else if (this.field === "SR_Short_Risk_Description__c") {
				this.textAreaStyle = true;
				this.isTextarea = true;
			} else {
				this.isTextarea = true;
			}
		} else if (this.type === "Rich Text Area") {
			this.isRichTextarea = true;
		} else if (this.type === "Picklist") {
			console.log(this.record.Id, this.record.RecordTypeId);
			this.isPicklist = true;
		} else if (this.type === "Multi Select") {
			this.isMultiSelect = true;
		} else if (this.type === "Record Link") {
			console.log('valueForLink###'+this.value);
			this.isRecordLink = true;
		} else if (this.type === "Output Text") {
			this.isOutputText = true;
		} else if (this.type === "Lookup") {
			/*if(this.field === 'SR_Site__c' || this.field === 'Site_Risk__c') {
				this.isOutputLookup = true;
			}
			else {
				this.isLookup = true;
			}*/
			this.isLookup = true;
		} else if (this.type === "Formula") {
			this.isFormula = true;
		} else if (this.type === "Currency") {
			this.isCurrency = true;
		} else if (this.type == "Picklist with Background") {
			if (this.value == "Blocked" || this.value == "High") {
				this.backgroundStyle = "background-color:red;";
			} else if (this.value == "In Progress" || this.value == "Medium") {
				this.backgroundStyle = "background-color:yellow;";
			} else if (this.value == "Complete" || this.value == "Low") {
				this.backgroundStyle = "background-color:green;";
			} else {
				this.showPicklist = true;
			}
			this.isBackgroundPicklist = true;
		} else if (this.type == "Checkbox") {
			this.isCheckBox = true;
		}
	}

	renderedCallback() {
		//console.log(this.field);
	}

	valueChange(event) {
		if (this.type == "Checkbox") {
			this.value = event.target.checked;
		} else {
			this.value = event.target.value;
		}
		console.log(JSON.stringify(this.record));
	}

	updateValue(event) {
		if (this.type == "Checkbox") {
			this.value = event.target.checked;
		} else {
			this.value = event.target.value;
		}
		if (this.isPicklist || this.isMultiSelect) {
			this.value = event.detail.selectedValue;
		}
		if (this.isBackgroundPicklist) {
			this.showPicklist = false;
			this.value = event.detail.selectedValue;
			if (this.value == "Blocked" || this.value == "High") {
				this.backgroundStyle = "background-color:red;";
			} else if (this.value == "In Progress" || this.value == "Medium") {
				this.backgroundStyle = "background-color:yellow;";
			} else if (this.value == "Complete" || this.value == "Low") {
				this.backgroundStyle = "background-color:green;";
			}
		}
		// Creates the event with the contact ID data.
		const selectedEvent = new CustomEvent("update", {
			detail: {
				recordId: this.record.Id,
				value: this.value,
				field: this.field
			}
		});
		// Dispatches the event.
		this.dispatchEvent(selectedEvent);
	}
	handleLookupSelection(event) {
		//alert("event");
		this.value = event.detail;
		//console.log(id,event.detail);
		const selectedEvent = new CustomEvent("update", {
			detail: {
				recordId: this.record.Id,
				value: this.value,
				field: this.field
			}
		});
		// Dispatches the event.
		this.dispatchEvent(selectedEvent);
	}

	@api
	state(record) {
		if (this.field === "State__c") {
			//this.isLoading = true;
			this.options = JSON.parse(record);
			//this.isLoading = false;
		}
	}

	@api
	showerror() {
		//this.isLoading = true;
		this.isError = true;
		//this.isLoading = false;
	}
	@api
	hideerror() {
		//this.isLoading = true;
		this.isError = false;
		//this.isLoading = false;
	}

	openRecord() {
		window.open("/" + this.record[this.redirectField], "_blank");
	}

	@api
	handleTestMethod(testVar) {
		this.updatedvalue = testVar;
		if (
			this.updatedvalue != null &&
			this.updatedvalue != "" &&
			this.updatedvalue != undefined &&
			this.updatedvalue.startsWith("a1j")
		) {
			this.isLookup = false;
			this.value = this.updatedvalue;
			clearTimeout(this.timeoutId);
			this.timeoutId = setTimeout(this.handleDelayAssignment.bind(this), 500);
		} else {
			console.log("else final##" + this.value);
			this.value = this.updatedvalue;
		}
	}

	handleDelayAssignment() {
		this.isLookup = true;
	}
				
	@api	
	updateLookup(){	
		this.value=this.record[this.field];	
		if(this.value){	
			const lookupToUpdate = this.template.querySelector('c-lookup-lwc');	
			lookupToUpdate.selectedRecordId = this.value;	
			lookupToUpdate.loadDefaultValue();	
		}	
	}	
	
	
	handleOnselect(event) {	
		event.preventDefault();	
		event.stopPropagation();	
	
			this[NavigationMixin.Navigate]({	
				type: 'standard__recordPage',	
				attributes: {	
					recordId: this.record.Id,	
					actionName: 'view'	
				}	
			});	
			
			
	}
}