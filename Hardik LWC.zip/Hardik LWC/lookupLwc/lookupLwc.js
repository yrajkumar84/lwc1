/**
 * Created by ekta.thakkar on 8/27/2020.
 */

import lookUp from "@salesforce/apex/Lookup.search";
import getCurrentValue from "@salesforce/apex/Lookup.getCurrentValue";
import getRecordTypeList from "@salesforce/apex/Lookup.getRecordTypeList";
import { api, LightningElement, track, wire } from "lwc";
export default class LookupLwc extends LightningElement {
	@api objName;
	@api iconName;
	@api filter = "";
	@api fields = [];
	@api newRecordFieldsRequired = false;
	@api searchPlaceholder = "Search";
	@api showCreateNew;
	@api lookupObjectField;
	@api isSiteRiskSnapshot;

	@track selectedName;
	@track records = [];
	@track isValueSelected;
	@api selectedRecordId;
	@track blurTimeout;
	@track recordTypeRecords = [];
	@track showCreateRecordForm = false;
	@track hasRecordType = false;
	@track recordTypeValue;
	@track isNextDisabled = true;
	@track showRemovedPill = false;

	searchTerm;
	//css
	@track boxClass = "slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click slds-has-focus";
	@track inputClass = "";

	@wire(lookUp, {
		searchTerm: "$searchTerm",
		myObject: "$objName",
		filter: "$filter"
	})
	wiredRecords({ error, data }) {
		console.log("called", error, data);
		if (data) {
			this.records = [];
			let r = [];
			r.Id = "New";
			r.Name = "+ Create New";
			if (this.showCreateNew) {
				this.records.push(r);
			}
			this.error = undefined;
			//this.records = data;
			//  console.log(data);
			for (let item in data) {
				let r = [];
				r.Id = data[item].Id;
				r.Name = data[item].Name;
				this.records.push(r);
			}
			/*let r  =[];
                        r.Id = 'New';
                        r.Name = '+ Create New';
               this.records.push(r);*/
			console.log("data", this.records);
		} else if (error) {
			this.error = error;

			console.log(error);
			// this.records = undefined;
		}
	}	

	connectedCallback() {
		console.log("lookupObjectField-----Lookup CMP-----" + this.lookupObjectField);
		console.log('objLookup###'+this.objName);
		this.getRecordType();
		if (this.selectedRecordId !== undefined && this.selectedRecordId !== "") {
			this.loadDefaultValue();
		}
	}
	loadDefaultValue() {
		getCurrentValue({
			type: this.objName,
			value: this.selectedRecordId,
			fields: this.lookupObjectField
		}).then((result) => {
			if (result !== "type" && result !== "Length" && result !== "User") {
				this.selectedName = result;
				this.isValueSelected = true;
			} else {
			}
		});
	}

	handleClick() {
		this.searchTerm = "";
		this.inputClass = "slds-has-focus";
		this.boxClass = "slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click slds-has-focus slds-is-open";
	}

	onBlur() {
		this.blurTimeout = setTimeout(() => {
			this.boxClass = "slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click slds-has-focus";
		}, 300);
	}

	onSelect(event) {
		let selectedId = event.currentTarget.dataset.id;
		let selectedName = event.currentTarget.dataset.name;
		console.log(selectedName);
		if (selectedId !== "New") {
			const valueSelectedEvent = new CustomEvent("lookupselected", {
				detail: selectedId
			});
			this.dispatchEvent(valueSelectedEvent);

			this.isValueSelected = true;

			this.selectedName = selectedName;
			this.selectedRecordId = selectedId;
			if (this.blurTimeout) {
				clearTimeout(this.blurTimeout);
			}
			this.boxClass = "slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click slds-has-focus";
		} else {
			this.showCreateRecordForm = true;
		}
	}

	handleRemovePill(event) {
		event.preventDefault();
		const valueSelectedEvent = new CustomEvent("remove", {
			detail: this.selectedRecordId
		});
		this.dispatchEvent(valueSelectedEvent);
		this.isValueSelected = false;
	}

	onChange(event) {
		this.searchTerm = event.target.value;
	}

	getRecordType() {
		getRecordTypeList({
			objectApiName: this.objName
		}).then((result) => {
			var optionArray = [];
			for (var i = 0; i < result.length; i++) {
				optionArray.push({
					label: result[i].Name,
					value: result[i].Id
				});
			}
			this.recordTypeRecords = optionArray;
			if (this.recordTypeRecords.length > 0) this.hasRecordType = true;
		});
	}
	handleRecordTypeChange(event) {
		this.recordTypeValue = event.target.value;
		this.isNextDisabled = false;
	}
	closeModal() {
		this.showCreateRecordForm = false;
	}
	handleNext() {
		this.hasRecordType = false;
	}
	handleSuccess(event) {
		this.selectedRecordId = event.detail.id;
		this.showCreateRecordForm = false;
		this.loadDefaultValue();

		const valueSelectedEvent = new CustomEvent("lookupselected", {
			detail: this.selectedRecordId
		});
		this.dispatchEvent(valueSelectedEvent);
	}
	openRecord() {
		window.open("/" + this.selectedRecordId, "_blank");
	}
}