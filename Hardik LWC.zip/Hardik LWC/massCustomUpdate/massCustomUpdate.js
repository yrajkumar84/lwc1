/**
 * Created by ekta.thakkar on 8/6/2020.
 */

 import { LightningElement, api, track, wire } from "lwc";
 import getFields from "@salesforce/apex/MassUpdateController.getFields";
 import getRecords from "@salesforce/apex/MassUpdateController.getRecords";
 import saveRecordList from "@salesforce/apex/MassUpdateController.saveRecordList";
 import saveSnapShotRecords from "@salesforce/apex/MassUpdateController.saveSnapShotRecords";
 import setValidatedDate from "@salesforce/apex/MassUpdateController.setValidatedDate";
 import createBulkUpdateSchemaRecord from "@salesforce/apex/MassUpdateController.createRecord";
 import fetchCustFilters from "@salesforce/apex/MassUpdateController.fetchCustFilters";
 import fetchSnapShotRecords from "@salesforce/apex/MassUpdateController.fetchSnapShotRecords";
 import fetchLatestSnapShotRecords from "@salesforce/apex/MassUpdateController.fetchLatestSnapShotRecords";
 //import getNextSteps from "@salesforce/apex/MassUpdateController.getNextSteps";
 import createOrUpdatePinnedFilter from "@salesforce/apex/MassUpdateController.createOrUpdatePinnedFilter";
 import { ShowToastEvent } from "lightning/platformShowToastEvent";
 import { loadScript, loadStyle } from "lightning/platformResourceLoader";
 import { getObjectInfo, getPicklistValuesByRecordType } from "lightning/uiObjectInfoApi";
 import RESOURCE_URL from "@salesforce/resourceUrl/countries";
 import Bulk_update_Validated_date_days from "@salesforce/label/c.CBU_Bulk_update_Validated_date_days";
 import ValidateButton from "@salesforce/label/c.CBU_Validate_Button";
 import CloneButton from "@salesforce/label/c.CBU_Clone_Button";
 import AttachFiles from "@salesforce/label/c.CBU_Attachment";
 import MarkClosed from "@salesforce/label/c.CBU_Attachment";
 import { createRecord } from 'lightning/uiRecordApi';
 import { updateRecord } from 'lightning/uiRecordApi';
 import { refreshApex } from '@salesforce/apex';
 import Id from '@salesforce/user/Id';
 import { subscribe, unsubscribe, onError, setDebuFlag, isEmpEnabled} from "lightning/empApi";
 import USER_ID from '@salesforce/user/Id';
 import InsertCaseComment from "@salesforce/apex/CaseCommentController.InsertCaseComment";
 
 export default class MassCustomUpdate extends LightningElement {
	 @api objectName = "Capacity__c";
	 @api snapshotObjName;
	 @api userId = Id;
	 @api filter;
	 @api filterFieldsByRecordType;
	 @track fieldMetaData = [];
	 @track records = [];
	 @track isUpdate = false;
	 @track isLoading = true;
	 @track showSaveButton = false;
	 @track sortedColumn = "Name";
	 @track sortedDirection = "desc";
	 @track isSortedASC = false;
	 @track message = "Changes not Saved";
	 @track messageStyle = "color:black;";
	 @track showActionButton = false;
	 @api isChildQuery = false;
	 @api recordId;
	 @api parentFieldName = "";
	 @track tableHeight;
	 @api heightInPixel;
	 @api searchField;
	 @api showSearch;
	 @api showFilter = false;
	 @api showPagination = false;
	 @api recordsPerPage = 100;
	 @track showFilterPane = false;
	 @track searchTerm = "";
	 @track filterSidePaneClass = "filter-popover-container  slds-hide";
	 @api showValidatedButton;	
	 @api showClonedButton;
	 @api showAttachmentButton;
	 @api showClosedButton;
	 @api overrideColumns = false;
	 @api overriddenColumns;
	 @api showLookupCreateOption;
	 @api searchFieldLabel='Owner Search';
	 @api objNameForLookUp;
	 @api showRadioGroup = false;
	 @api showLookupWithoutCreateOption;
	 @api lookupFilterValues;
	 @api timeoutId;
	 @api snapRecIds = [];
	 @api prevNextStepRecords = [];
	 @api showRefresh = false;
	 @api disableSnapRecord = false;
	 @api updatedRecords = [];
	 @track finalCustFiltersList;
	 @track custFiltersMap = new Map();
	 @track selectedFilterName;
	 @track selectedFilterId;
	 @api finalFilterList;
	 @api finalFilterLogic = "";
	 @track disableEditThisFilter = false;
	 @track pinCurrentFilter = false;
	 @track dmlMode = 'INSERT';
 
	 @track finalCustFiltersListArray;
	 @track newCustFilterName;
	 @track newCustFilterVisibility = true;
	 @track newCustFilterId;
	 @track isNewCustFilterModal = false;
	 @api pageOnCommunity;
	 @track applicableFilters;
	 @track recordsInitial;
	 @track recordsForPagination;
	 @track dRecordTypeId;
	 @track defaultRecordTypePicklistFields;
	 @track filterInitial;
	 @track recordRowCls;
	 @track selectedRegion;
	 @track selectedView;
	 //@track siteRiskMap = new Map();
	 @track selectedDateView;
	 @track isCloned = false;
	 @track channelName;
	 @track showSnapShotSaveMessage = false;
	 @track showCloneSnapshot = false;
	 @track showSnapshotBtn = false;
	 @track totalSnapshotRecords = [];
	 @track IsSnapShot = false;
     @track fullRecords=[];

	 _cartItems;
	 _deleteFiltChange;
	 value = '';
 
	 get options() {
		 return [
			 { label: 'AMER', value: 'AMER' },
			 { label: 'APAC', value: 'APAC' },
			 { label: 'EMEA', value: 'EMEA' }
		 ];
	 }
 
	 @api
	 get cartItems(){
	 return this._cartItems;
	 }
 
	 set cartItems(value){
	 this._cartItems = JSON.parse(JSON.stringify(value));
	 }
 
	 @api
	 get deleteFiltChange(){
	 return this._deleteFiltChange;
	 }
 
	 set deleteFiltChange(value){
	 this._deleteFiltChange = JSON.parse(JSON.stringify(value));
	 }
 
	 label = {
		 Bulk_update_Validated_date_days,
		 ValidateButton,
		 CloneButton,
		 AttachFiles,
		 MarkClosed
	 };
	 
	subscription = {};  
 
	 handleSubscribe() {
		 const messageCallback = (response) => {
			 this.handleResponse(response);
		 }
 
		 subscribe(this.channelName, -1, messageCallback).then(response => {
			 console.log('Subscription request sent to: ', JSON.stringify(response.channel));
			 this.subscription = response;
		 });
	 }
 
	 handleResponse(response) {
		console.log('response in channel###'+JSON.stringify(response));
		if(response.data.payload.LastModifiedById__c != USER_ID) {
			let serverResp = response.data.payload;	
			console.log('metadata value###'+JSON.stringify(this.fieldMetaData));
			for (let i in this.fieldMetaData) {
				let field = this.fieldMetaData[i];
				let row = this.template.querySelectorAll("c-mass-update-child[data-recid=" + serverResp.Record_Id__c + "]");
				for (let i = 0; i < row.length; i++) {				
					if (row[i].dataset.recid === serverResp.Record_Id__c && row[i].dataset.fieldname === field.Field_Name__c) {
						row[i].handleTestMethod(serverResp[field.Field_Name__c]);
					}
				}
			}
		}
				
	 }
 
 
	 registerErrorListener() {
		 // Invoke onError empApi method
		 onError(error => {
			 console.log('Received error from server: ', JSON.stringify(error));
			 // Error contains the server-side error
		 });
	 }
 
 
	 @wire(getObjectInfo, { objectApiName: "$objectName" })
	 objectInfo({ error, data }) {
		 if (data) {
			 this.dRecordTypeId = data.defaultRecordTypeId;
		 } else if (error) {
			 console.log("@#@ error " + JSON.stringify(error));
		 }
	 }
 
	 @wire(getPicklistValuesByRecordType, { recordTypeId: "$dRecordTypeId", objectApiName: "$objectName" })
	 wiredOptions({ error, data }) {
		 if (data) {
			 if (this.dRecordTypeId) {
				 this.defaultRecordTypePicklistFields = {
					 rTypeId: this.dRecordTypeId,
					 picklistFields: data.picklistFieldValues
				 };
			 }
		 } else if (error) {
			 console.log("@#@ error " + JSON.stringify(error));
		 }
	 }
 
	 connectedCallback() {
		 this.channelName = '/event/Auto_Refresh__e';
		 this.registerErrorListener();
		 this.handleSubscribe();
		 if(this.objectName == 'Site_Risk_Snapshot_Record__c') {
			 this.showRadioGroup = true;
			 this.showLookupWithoutCreateOption = false;
			 this.disableSnapRecord = true;
			 this.message = '';
			 this.IsSnapShot = true;
		 }
		 if (this.showValidatedButton || this.showClonedButton || this.showAttachmentButton) {
			 this.showActionButton = true;
		 }
		 this.tableHeight = "height: " + this.heightInPixel;
		this.selectedRegion = undefined;
		 Promise.all([loadScript(this, RESOURCE_URL)])
			 .then(() => {
				 this.init();
			 })
			 .catch((error) => {
				 console.log(error);
			 });
	 }
 
	 init() {
		 this.isLoading = true;
		 //this.actualVallll = [];
		 getFields({
			 objectName: this.objectName,
			 parentFieldName: this.parentFieldName,
			 recordType : this.filterFieldsByRecordType
		 })
			 .then((result) => {
				 if (result) {
					 this.fieldMetaData = result;
					 
					 if (this.overrideColumns) {
						 let overriddenCols = [];
						 this.overriddenColumns.split(",").forEach((element) => {
							 overriddenCols.push(element.trim());
						 });
						 this.fieldMetaData = this.fieldMetaData.filter((element) => {
							 return overriddenCols.includes(element.Field_Name__c);
						 });
					 }
					 this.fetchRecords();
					 //this.fetchFilterRecords();
				 }
			 })
			 .catch((e) => {
				 this.isLoading = false;
			 });
	 }
 
	 fetchRecords() {
		 this.records = [];
		 this.actualRecords = [];
		 this.finalRecords = [];
		 this.isLoading = true;
		 console.log('called from save###');
		 getRecords({
			 objectName: this.objectName,
			 isChildQuery: this.isChildQuery,
			 parentRecordId: this.recordId,
			 parentFieldName: this.parentFieldName,
			 searchField: this.searchField,
			 searchTerm: this.searchTerm,
			 filter : this.filter !== undefined ? this.filter : ''
		 }).then((result) => {
			 if (result) {
				/*if(this.objectName == 'Site_Risk_Snapshot_Record__c') {
					 for(let item in this.fieldMetaData) {
						 this.siteRiskMap.set(this.fieldMetaData[item].Field_Name__c,this.fieldMetaData[item].Field_Type__c);
						 //this.fieldMetaData[item].Field_Type__c = 'Output Text';
						 if(this.fieldMetaData[item].Field_Name__c == 'Site_Risk__c') {
							 //this.fieldMetaData[item].Field_Name__c = 'Site_Risk_Name__c';
						 }
					 }
				 }*/
				 console.log('recs####'+JSON.stringify(result));
				 this.actualRecords = result;
				 this.showSaveButton = false;
				 if(this.objectName != null && this.objectName != '' && this.objectName != undefined && this.objectName == 'Site_Risk_Snapshot_Record__c' && !this.isCloned) {
					 
					this.records = [];
				 }
				 else {
					 this.records = result;
				 
				 //this.actualRecords = result;
				 let countries = this.populate_country((e) => {
					 console.log("Country Response");
				 });
				 let newRecords = [];
				 for (let item in this.records) {
					 var todayDate = new Date();
					 let month = todayDate.getMonth() + 1;
					 month = month < 10 ? "0" + month : month;
					 let day = todayDate.getDate();
					 day = day < 10 ? "0" + day : day;
					 let dt = todayDate.getFullYear() + "-" + month + "-" + day;
					 this.records[item].isChanged = false;
					 this.records[item].isError = false;
					 if (this.records[item].Cloned_Date__c === dt) {
						 this.records[item].showCloneButton = false;
						 this.records[item].style = "background-color:yellow;";
					 } else {
						 this.records[item].style = "";
						 this.records[item].showCloneButton = true;
					 }
					 if (this.objectName === "Capacity__c") {
						 const date1 = new Date(this.records[item].Validated_Date__c);
						 const date2 = new Date();
						 const diffTime = Math.abs(date2 - date1);
						 const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
						 //if (this.records[item].hasOwnProperty('Country__c')) {
						 //console.log('Countries ',this.records[item].Id , countries);
						 this.records[item].countryOptions = JSON.stringify(countries);
						 if (this.records[item].hasOwnProperty("Country__c") && this.records[item].Country__c !== "") {
							 this.records[item].stateOptions = JSON.stringify(this.getStates(this.records[item].Country__c));
						 }
						 //  }
						 if (
							 !this.records[item].hasOwnProperty("Validated_Date__c") ||
							 this.records[item].Validated_Date__c === "" ||
							 diffDays > 15
						 ) {
							 this.records[item].showValidateButton = true;
						 } else {
							 this.records[item].showValidateButton = false;
						 }
					 } else {
						 this.records[item].showValidateButton = false;
					 }
					 if(this.records[item].Color__c != null && this.records[item].Color__c != '' && this.records[item].Color__c != undefined) {
						 //this.records[item].rowCls = this.records[item].Color__c + 'ReadOnlyRowCls';
					 }	
					 else {
						 //this.records[item].rowCls = 'readOnlyCls';
					 }
					 this.snapRecIds.push(this.records[item].Id);
				 }
				 }
				 this.isLoading = false;
				 this.recordsInitial = JSON.parse(JSON.stringify(this.records));
				 console.log('this.records',this.recordsInitial );
				 if (this.applicableFilters) {
					 this.isLoading = true;
					 
					 this.applyFilterOnRecords(this.applicableFilters);
					 this.isLoading = false;
				 } else if (this.showPagination) {
					 this.recordsForPagination = JSON.parse(JSON.stringify(this.records));
				 }
			 }
			 console.log('===isclone==='+this.isCloned);
			 if(this.isCloned){
				 let newRecords = [];
				 this.records = this.actualRecords;
				 for (let item in this.records) {
					 if(this.records[item].Site_Risk_Snapshot_Date__c == this.selectedDateView) {
						 newRecords.push(this.records[item]);
					 }
					 
				 }
				 console.log("===savennel====="+JSON.stringify(newRecords));
				 this.records = newRecords;
				 console.log("===new rec====="+JSON.stringify(this.records));
			 }
			 //this.fetchNextStepsRecord(this.snapRecIds);
		 });
	 }
 
	 /*fetchNextStepsRecord(snapRecordIds) {
		 console.log('called from wire');
		 getNextSteps({
			 nextStepsIds: snapRecordIds
		 }).then((result) => {
			 console.log('result from wire####'+JSON.stringify(result));
			 let nxtStepResult = result;
			 for(var key in nxtStepResult){
				 this.prevNextStepRecords.push({value:nxtStepResult[key], key:key});
			 }	
		 })
		 .catch(error=>{
			 console.log(error);
			 this.message = error.body.pageErrors[0].statusCode + '- '+ error.body.pageErrors[0].message;
		 });
		 console.log('mapResult###'+this.prevNextStepRecords);
	 }*/
 
	 fetchFilterRecords() {
		 fetchCustFilters({
			 objectName : this.objectName
		 }).then((result) => {
			 if(result) {
				 
				 let options = [];
				 for(let i in result) {
					 if(result.hasOwnProperty(i)) {
						 options.push({value:result[i].Name, label:result[i].Name});
					 }
				 } 
				 this.finalCustFiltersList = options;
			 }
		 });
	 }
 
	 @wire(fetchCustFilters, { objectName: "$objectName" }) custFilter(result) {
		 this.finalCustFiltersListArray = result;
		 if (result.data) {
			 let options = [];
			 
			 console.log('result',JSON.stringify(result.data));
			 this.filterInitial = result.data;
			 for(let i in result.data) {
				 if(result.data.hasOwnProperty(i)) {
 
					 options.push({value:result.data[i].Id, label:result.data[i].Name});
					 if(result.data[i].hasOwnProperty('Pinned_Filters__r') && this.selectedFilterId == undefined) {
						 
						 this.selectedFilterId = result.data[i].Id;
						 console.log('applicableFilters',this.applicableFilters);
						 this.applicableFilters = {};
						 if(result.data[i].Filter_Logic__c !== null && result.data[i].Filter_Logic__c !== '' && result.data[i].Filter_Logic__c !== undefined){
							 this.applicableFilters.filterLogic = result.data[i].Filter_Logic__c;
						 } else {
							 this.applicableFilters.filterLogic = "";//result.data[i].Filter_Logic__c;
						 }
						 
						 this.applicableFilters.filterList = JSON.parse(result.data[i].Filter_Values__c);
						 console.log('applicableFilters',this.applicableFilters);
					 }
				 }
				 console.log('=====name==='+result.data[i].Name);
				 console.log('=====name==='+result.data[i]);
				 this.custFiltersMap.set(result.data[i].Id, result.data[i]);
			 } 
			 console.log('custFiltersMap###'+JSON.stringify(this.custFiltersMap));
			 //console.log('options###'+JSON.stringify(options));
			 //console.log('sort###'+JSON.stringify(options.sort()));
			 this.finalCustFiltersList = options;
		 }
		 console.log('wire ##'+JSON.stringify(this.finalCustFiltersListArray));
	 }
 
	 handlePaginationResponse(event) {
		 this.records = event.detail.recordsToShow;
	 }
 
	 handleFilterButtonClick(event) {
		 this.isLoading = true;
		 this.showFilterPane = !this.showFilterPane;
		 //this.showFilter = false;
		 this.filterSidePaneClass = "filter-popover-container slds-hide";
		 this.isLoading = false;
	 }
 
	 hideFilterEditPane(event) {
		 this.isLoading = true;
		 this.filterSidePaneClass = "filter-popover-container slds-hide";
		 this.isLoading = false;
	 }
 
	 triggerUpdateFilterValueLists(event) {
		 this._cartItems = event.detail;
		 this.isLoading = true;
		 if (this.template.querySelector("c-mass-custom-update-filter")) {
			 this.template.querySelector("c-mass-custom-update-filter").updateFilterLists(this._cartItems);
			 this.filterSidePaneClass = "filter-popover-container slds-hide";
		 }
		 this.isLoading = false;
	 }
 
	 triggerAddNewFilter(event) {
		 this.isLoading = true;
		 let filterToEdit = { filterField: "", operator: "", valueToFilter: null };
		 let valueToSend = { index: -1, filterValue: filterToEdit, isSaved: false };
		 this.updateFilterSelection(valueToSend);
		 this.filterSidePaneClass = "filter-popover-container slds-show";
		 this.isLoading = false;
	 }
	 triggerEditFilter(event) {
		 this.isLoading = true;
		 this.updateFilterSelection(event.detail);
		 this.filterSidePaneClass = "filter-popover-container slds-show";
		 this.isLoading = false;
	 }
 
	 updateFilterSelection(value) {
		 if (this.template.querySelector("c-mass-custom-update-filter-edit")) {
			 this.template.querySelector("c-mass-custom-update-filter-edit").updateFilterEditSelection(value);
		 }
	 }
 
	 triggerFilterRecordDelete(event) {
		 this._deleteFiltChange = event.detail;
		 this.isLoading = true;
		 if (this.template.querySelector("c-mass-custom-update-filter")) {
			 this.template.querySelector("c-mass-custom-update-filter").deleteSelectedFilterRecord(this._deleteFiltChange);
			 this.filterSidePaneClass = "filter-popover-container slds-hide";
		 }
		 this.isLoading = false;
	 }
 
	 applyFilterOnRecords(value) {
		 console.log('====value==='+value);
		 this.records = [];
		 this.records = JSON.parse(JSON.stringify(this.recordsInitial));
		 this.filterSidePaneClass = "filter-popover-container slds-hide";
		 if (!value.filterLogic && value.filterList.length == 0) {
			 if (this.showPagination) {
				 this.recordsForPagination = JSON.parse(JSON.stringify(this.records));
			 }			return;
		 }
		 this.records = this.records.filter((element) => {
			 return this.filterRecords(value.filterLogic, value.filterList, element);
		 });
		 if (this.showPagination) {
			 this.recordsForPagination = JSON.parse(JSON.stringify(this.records));
		 }
	 }
 
	 triggerRecordFilter(event) {
		 console.log('from###'+JSON.stringify(event.detail));
		 this.isLoading = true;
		 this.applicableFilters = event.detail;
		 this.updateCustFilterList(event.detail);
		 this.applyFilterOnRecords(event.detail);
		 this.isLoading = false;
	 }
 
	 filterRecords(filterCondition, filters, recordObj) {
		 console.log('======');
		 console.log('====inside filterrecordsss filterCondition=='+filterCondition);
		 console.log('====inside filterrecordsss filters=='+filters);
		 console.log('====inside filterrecordsss recordObj=='+recordObj);
 
		 for (let i = 1; i <= filters.length; i++) {
			 let bool = this.processFilterOperation(recordObj, filters[i - 1]);
			 console.log('==bool===='+bool);
			 if (filterCondition && filterCondition.includes(i.toString())) {
				 console.log('===if===');
				 filterCondition = filterCondition.replace(i.toString(), bool.toString());
			 } else {
				 console.log('==else====');
				 if (filterCondition) {
					 console.log('===if if===');
					 filterCondition += " AND " + bool.toString();
				 } else {
					 console.log('====if else==');
					 filterCondition += bool.toString();
				 }
			 }
		 }
		 console.log('=====filterCondition='+filterCondition);
		 filterCondition = filterCondition!=undefined?filterCondition.replaceAll("AND", "&&").replaceAll("OR", "||"):"";
		 console.log('------------------filterCondition------------------',filterCondition);
		 return eval(filterCondition);
	 }
 
	 processFilterOperation(record, filter) {
		 console.log('====process==='+JSON.stringify(filter), filter);
		 //console.log(filter.filterValue.operator);
		 let operator = filter.operator ? filter.operator : filter.filterValue.operator;
		 let filterField = filter.filterField ? filter.filterField : filter.filterValue.filterField;
		 let valueToFilter = filter.hasOwnProperty('valueToFilter') ? filter.valueToFilter : filter.filterValue.valueToFilter;
		 switch (operator) {
			 case "equals":
				 console.log('equals-------------', record[filterField], valueToFilter, record[filterField] === valueToFilter, record[filterField] == valueToFilter);
				 record[filterField] = record[filterField] == undefined ? '' : record[filterField];
				 return record[filterField] == valueToFilter;
				 break;
			 case "not equal to":
				 record[filterField] = record[filterField] == undefined ? '' : record[filterField]
 
				 return record[filterField] != valueToFilter;
				 break;
			 case "less than":
				 return record[filterField] < valueToFilter;
				 break;
			 case "greater than":
				 return record[filterField] > valueToFilter;
				 break;
			 case "less or equal":
				 record[filterField] = record[filterField] == undefined ? '' : record[filterField]
 
				 return record[filterField] <= valueToFilter;
				 break;
			 case "greater or equal":
				 record[filterField] = record[filterField] == undefined ? '' : record[filterField]
 
				 return record[filterField] >= valueToFilter;
				 break;
			 case "contains":
				 if (!record[filterField]) {
					 return false;
				 } else {
					 return record[filterField].includes(valueToFilter);
				 }
				 break;
			 case "does not contain":
				 if (!record[filterField]) {
					 return false;
				 } else {
					 return !record[filterField].includes(valueToFilter);
				 }
				 break;
			 case "start with":
				 if (!record[filterField]) {
					 return false;
				 } else {
					 return record[filterField].startsWith(valueToFilter);
				 }
				 break;
			 default:
				 
				 return false;
				 break;
		 }
	 }
 
	 updateRecord(event) {
		 console.log('objName###'+this.objectName);
		 console.log('fullll###'+JSON.stringify(this.records));
		 for (let item in this.records) {
			 if (this.records[item].Id === event.detail.recordId) {
				 let tempObj = JSON.parse(JSON.stringify(this.records[item]));
				 tempObj.isChanged = true;
				 tempObj[event.detail.field] = event.detail.value;
				 if (event.detail.field === "Country__c") {
					 this.isLoading = true;
					 tempObj.State__c = "";
					 tempObj.stateOptions = JSON.stringify(this.getStates(event.detail.value));
					 let r = this.template.querySelectorAll("c-mass-update-child[data-recid=" + tempObj.Id + "]");
					 for (let i = 0; i < r.length; i++) {
						 if (r[i].dataset.recid === tempObj.Id && r[i].dataset.fieldname === "State__c") {
							 r[i].state(tempObj.stateOptions);
							 this.isLoading = false;
						 }
					 }
				 }
				 this.records.splice(parseInt(item), 1, tempObj);
				 break;
			 }
		 }
		 if(this.objectName == 'Site_Risk_Snapshot_Record__c') {
			// console.log('fullll###'+JSON.stringify(this.records));
			 this.showSnapShotSaveMessage = true;
			 this.message = 'Saving the changes';
			 clearTimeout(this.timeoutId);
			 this.timeoutId = setTimeout(this.save.bind(this), 3000);
		 }
		 else {
			this.showSaveButton = true;
			// this.saveRecords();
		 }
	 }
	 saveRecords() {
		 this.validate();
	 }
	 validate() {
		 this.isLoading = true;
		 let validationPass = true;
		 for (let item in this.records) {
			 let r = JSON.parse(JSON.stringify(this.records[item]));
			 r.style = "background-color:''";
			 if (r.isChanged) {
				 let fieldValid = true;
				 for (let i in this.fieldMetaData) {
					 let field = this.fieldMetaData[i];
					 if (field.Is_Active__c && field.Is_Mandatory__c) {
						 if (
							 r[field.Field_Name__c] === "" ||
							 r[field.Field_Name__c] === null ||
							 r[field.Field_Name__c] === undefined
						 ) {
							 let row = this.template.querySelectorAll("c-mass-update-child[data-recid=" + r.Id + "]");
							 for (let i = 0; i < row.length; i++) {
								 if (row[i].dataset.recid === r.Id && row[i].dataset.fieldname === field.Field_Name__c) {
									 row[i].showerror();
									 r.style = "background-color:pink;";
								 }
							 }
							 validationPass = false;
							 fieldValid = false;
						 } else {
							 let row = this.template.querySelectorAll("c-mass-update-child[data-recid=" + r.Id + "]");
							 for (let i = 0; i < row.length; i++) {
								 if (row[i].dataset.recid === r.Id && row[i].dataset.fieldname === field.Field_Name__c) {
									 row[i].hideerror();
								 }
							 }
						 }
					 }
					 /* if (fieldValid) {
					 } */
				 }
			 }
			 this.records.splice(parseInt(item), 1, r);
		 }
		 if (validationPass) {
			 this.message = "Changes not Saved";
			 //this.messageStyle ="color:black;";
			 this.save();
		 } else {
			 this.message = "Error Occurred! Please check the page to see the error.";
			 //this.messageStyle ="color:red;";
		 }
		 this.isLoading = false;
	 }
	 save() {
		 console.log('called after timeout 333' + JSON.stringify(this.records));
		 this.totalSnapshotRecords = this.records;
		 let rlist = [];
		 for (let item in this.records) {
			 let r = this.records[item];
			 if (r.isChanged) {
				 rlist.push(r);
			 }
		 }
		 saveRecordList({
			 recordList: rlist
		 }).then((result) => {
			 if(this.objectName == 'Site_Risk_Snapshot_Record__c') {
				 console.log('server called successfully###');
				this.message = 'Changes were saved';
				
				console.log('Ram====='+JSON.stringify(this.records));
				this.totalSnapshotRecords = this.records;
			 }

			 else{
				this.message = "Changes not Saved";
				this.dispatchEvent(
					new ShowToastEvent({
						title: "Success",
						message: `Records Saved Successfully!`,
						variant: "success"
					})
				);
				this.showSaveButton = false;
				this.records = [];
				this.fetchRecords();
			 } 
			 console.log("Record Saved Successful"+this.selectedDateView);
		 })
		 .catch(error=>{
			 console.log(error);
			 this.message = error.body.pageErrors[0].statusCode + '- '+ error.body.pageErrors[0].message;
		 });
		 
	 }
	 populate_country() {
		 // given the id of the <select> tag as function argument, it inserts <option> tags
		 let options = [];
		 let option = [];
		 option.value = "";
		 option.label = "Select Country";
		 let countryArr = _countries.getCountries();
 
		 for (var i = 0; i < countryArr.length; i++) {
			 option = [];
			 option.value = countryArr[i];
			 option.label = countryArr[i];
			 options.push({
				 label: countryArr[i],
				 value: countryArr[i]
			 });
		 }
		 console.log("country options", options);
		 return options;
	 }
	 getStates(country) {
		 this.value = "";
		 let countries = _countries.getCountries();
		 let index = countries.indexOf(country);
		 console.log(index);
		 let states = _states.getStates();
		 console.log(states[index + 1]);
		 let statesArr = states[index + 1].split("|");
		 let options = [];
		 for (let i = 0; i < statesArr.length; i++) {
			 options.push({
				 label: statesArr[i],
				 value: statesArr[i]
			 });
		 }
		 return options;
	 }
	 validateRecord(event) {
		 let validaterecId = event.target.dataset.recid;
		 // this.test=true;
		 setValidatedDate({
			 recordId: validaterecId
		 })
			 .then(() => {
				 this.dispatchEvent(
					 new ShowToastEvent({
						 title: "Success",
						 message: `Records validated succesfully!`,
						 variant: "success"
					 })
				 );
				 for (let item in this.records) {
					 if (validaterecId === this.records[item].Id) {
						 this.records[item].showValidateButton = false;
					 }
				 }
			 })
			 .catch((error) => {
				 this.error = error;
				 this.record = undefined;
			 });
	 }
	 cloneRecord(event) {
		 this.isLoading = true;
		 for (let item in this.records) {
			 if (event.target.dataset.recid === this.records[item].Id) {
				 createBulkUpdateSchemaRecord({
					 record: this.records[item],
					 objectName: this.objectName
				 }).then((result) => {
					 this.dispatchEvent(
						 new ShowToastEvent({
							 title: "Success",
							 message: `Record Cloned Successfully!`,
							 variant: "success"
						 })
					 );
					 this.records = [];
					 this.fetchRecords();
				 });
			 }
		 }
	 }
 
	 sort(e) {
		 this.isLoading = true;
		 console.log('sort id###'+e.currentTarget.dataset.id);
		 if (this.sortedColumn === e.currentTarget.dataset.id) {
			 this.sortedDirection = this.sortedDirection === "asc" ? "desc" : "asc";
			 if (this.sortedDirection === "asc") this.isSortedASC = true;
			 else this.isSortedASC = false;
		 } else {
			 this.sortedDirection = "asc";
 
			 this.isSortedASC = true;
		 }
		 var reverse = this.sortedDirection === "asc" ? 1 : -1;
		 let table;
		 if (this.showPagination) {
			 table = JSON.parse(JSON.stringify(this.recordsForPagination));
		 } else {
			 table = JSON.parse(JSON.stringify(this.records));
		 }
 
		 table.sort((a, b) => {
			 return a[e.currentTarget.dataset.id] > b[e.currentTarget.dataset.id] ? 1 * reverse : -1 * reverse;
		 });
		 this.sortedColumn = e.currentTarget.dataset.id;
		 if (this.showPagination) {
			 this.recordsForPagination = table;
		 } else {
			 this.records = table;
		 }
		 this.isLoading = false;
	 }
	 openAttachmentRecord(event) {
		 let id = event.target.dataset.recid;
		 window.open("/s/relatedlist/" + id + "/CombinedAttachments", "_blank");
	 }
 
	 handleSearchChange(event) {
		 this.searchTerm = event.target.value;
		 console.log('called on change###'+this.searchTerm);
	 }
 
	 handleCustFilterChange(event) {
		 this.selectedFilterId = event.target.value;
		 console.log('id####'+this.selectedFilterId);
		 this.selectedFilterName = this.custFiltersMap.get(this.selectedFilterId).Name;
		 this.disableEditThisFilter = false;
		 for (let item in this.filterInitial) {
			 let result = this.filterInitial[item];
			 if (result.Id === this.selectedFilterId) {
				 this.applicableFilters = {};
				 if (result.Filter_Logic__c !== null && result.Filter_Logic__c !== '' && result.Filter_Logic__c !== undefined) {
					 this.applicableFilters.filterLogic = result.Filter_Logic__c;
				 } else {
					 this.applicableFilters.filterLogic = "";//result.data[i].Filter_Logic__c;
				 }
 
				 this.applicableFilters.filterList = JSON.parse(result.Filter_Values__c);
				 this.applyFilterOnRecords(this.applicableFilters);
				 this.showFilterPane = false;
 
				 break;
 
			 }
		 }
 
		 
	 /*	let tempfiltervalues =[];
		 let finalfiltervalues = JSON.parse(this.custFiltersMap.get(this.selectedFilterId).Filter_Values__c);
		 finalfiltervalues.forEach((element) => {
			 tempfiltervalues.push(element.filterValue);
		 });
		 console.log('=tempfiltervalues===='+JSON.stringify(tempfiltervalues));
		 this.recordsToDisplay = [];
		 this.recordsToDisplay = JSON.parse(JSON.stringify(this.recordsInitial));
		 this.recordsToDisplay = this.recordsToDisplay.filter((element) => {
			 if(this.custFiltersMap.get(this.selectedFilterId).Filter_Logic__c!=undefined){
			 this.filterRecords(this.custFiltersMap.get(this.selectedFilterId).Filter_Logic__c, tempfiltervalues, element);
			 refreshApex(this.finalCustFiltersListArray);
		 }
		 });*/
		 
	 }
 
	 handleCustFilterSelect(event) {
		 let selectedCustFilter = event.detail.value;
		 if(selectedCustFilter == 'NewFilter') {
			 this.isNewCustFilterModal = true;
		 }
		 else if(selectedCustFilter == 'EditThisFilter') {
			 this.showExistingFilter(event);
			 //this.showFilter = true;
			 this.showFilterPane = true;
		 }
		 else if(selectedCustFilter == 'PinThisFilter') {
			 this.pinCurrentFilter = true;
			 this.updatePinnedFilter();
		 }
	 }
 
	 createNewCustFilter(event) {
		 let filterValues = this.template.querySelectorAll('lightning-input');
		 filterValues.forEach(function(element){
			 if(element.name=="filterName") {
				 this.newCustFilterName=element.value;
			 }
			 if(element.name=="filterVisibility") {
				 this.newCustFilterVisibility=element.checked;
			 }
		 },this);
		 const recordInput = {
			 "apiName": "Custom_Filters__c",
			 "fields" : {
			   "Name": this.newCustFilterName,
			   "Object_API__c" : this.objectName,
			   "Public_Filter__c" : this.newCustFilterVisibility,
			   "Filter_Values__c" : '[]'
			 }
		   };
		   
		 createRecord(recordInput)
			 .then(result => {
				 this.dispatchEvent(
					 new ShowToastEvent({
						 title: "Success",
						 message: "List View created successfully!",
						 variant: "success"
					 })
				 );
				 //this.finalCustFiltersList.push({value:result.fields.Name.value, label:result.fields.Name.value});
				 this.isNewCustFilterModal = false;
				 refreshApex(this.finalCustFiltersListArray);
			 })
	 }
 
	 updateCustFilterList(value) {
		 console.log('====gf=='+JSON.stringify(value));
		 const recordInput = {
			 "fields" : {
			   "Name": this.selectedFilterName,
			   "Id" : this.selectedFilterId,
			   "Filter_Logic__c" : value.filterLogic.replace(/\"/g, ""),
			   "Filter_Values__c" : JSON.stringify(value.filterListValues),
			   "Is_Pinned_Filter__c" : this.pinCurrentFilter
			 }
		   };
		   updateRecord(recordInput)
				 .then(() => {
					 console.log('=inside=====');
					 this.dispatchEvent(
						 new ShowToastEvent({
							 title: 'Success',
							 message: 'Filter updated',
							 variant: 'success'
						 })
					 );
					 return refreshApex(this.finalCustFiltersListArray);
				 })
				 .catch(error => {
					 this.dispatchEvent(
						 new ShowToastEvent({
							 title: 'Error updating filter',
							 message: error.body.message,
							 variant: 'error'
						 })
					 );
				 });
				 
	 }
 
	 updatePinnedFilter() {
		 console.log('idinmeth####'+this.selectedFilterId);
		 createOrUpdatePinnedFilter({
			 currentFilterId : this.selectedFilterId,
			 objectApiName : this.objectName
		 }).then((result) => {
			 if(result) {
				 refreshApex(this.finalCustFiltersListArray); 
			 }
		 });
	 }
 
	 showExistingFilter() {
		 //let filtLogic = this.custFiltersMap!=null && this.custFiltersMap!=undefined && this.custFiltersMap.get(this.selectedFilterId).Filter_Logic__c!=null && this.custFiltersMap.get(this.selectedFilterId).Filter_Logic__c!=undefined?this.custFiltersMap.get(this.selectedFilterId).Filter_Logic__c:null;
		 let filtValues = this.custFiltersMap.get(this.selectedFilterId).Filter_Values__c;
		 let filtLogic = this.custFiltersMap.get(this.selectedFilterId).Filter_Logic__c;
		 this.finalFilterList = filtValues!=null?JSON.parse(filtValues):[];
		 this.finalFilterLogic = filtLogic!=null?filtLogic:"";
		 
		 //let existingFilterListToSend = {filterLogic : filtLogic, filterList: filtValues};
		 //let existingFilterValuesToSend = {"index":-1,"filterValue":{"filterField":"AZ__c","operator":"not equal to","valueToFilter":"hjjb","filterFieldLabel":"AZ"},"isSaved":false};
		 /*const existingFilterEvent = new CustomEvent("editexistingfilter", {
			 detail: finalFilterList
		 });
		 this.dispatchEvent(existingFilterEvent);*/
		 //this.triggerUpdateFilterValueLists(existingFilterEvent);
	 }
 
	 closeCustFilterModal() {
		 this.isNewCustFilterModal = false;
	 }
	 
	 handleLookupSelection(event){
		 console.log('called after one##'+this.selectedDateView);
		 console.log('===value'+event.detail);
		 this.selectedDateView = event.detail;
		 this.value = event.detail;
		 let newRecords = [];
		 this.records = this.actualRecords;
		 for (let item in this.records) {
			 if(this.records[item].Site_Risk_Snapshot_Date__c == this.selectedDateView) {
				 newRecords.push(this.records[item]);
			 }
		 }
		 this.records = newRecords;
		 //refreshApex(this.actualRecords);
	 }
 
	 handleSelected(event) {
		this.disableSnapRecord = true;
		let todayDate = new Date();
		const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
		"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
	    ];
		let todayDayWithTrailingZero = (todayDate.getDate() < 10 ? '0' : '') + todayDate.getDate();
		let currentDate = monthNames[todayDate.getMonth()] + ' ' + todayDayWithTrailingZero + ' ' + todayDate.getFullYear();
		 this.selectedRegion = event.target.value;
		 this.showLookupWithoutCreateOption = false;
		 this.value = '';
		 this.handleLatestSnapShotRecords();
	 }
	 handleLatestSnapShotRecords() {
		fetchLatestSnapShotRecords({
			region : this.selectedRegion
		}).then((result) => {
			console.log('result from server###'+JSON.stringify(result));
			this.lookupFilterValues = 'SR_Region__c=\''+this.selectedRegion+'\'';
			this.showLookupWithoutCreateOption = true;
			this.isSnapShotSelected = true;
			this.records = result;
			this.fullRecords = result;
			this.totalSnapshotRecords = result;
			this.value = result[0].Site_Risk_Snapshot_Date__c;
			this.selectedDateView = result[0].Site_Risk_Snapshot_Date__c;
			this.recordsForPagination = JSON.parse(JSON.stringify(this.records));
			/* console.log('currentDate####'+currentDate);
			if(result[0].Site_Risk_Snapshot_Date__r.Name != currentDate) {
			   this.showSnapshotBtn = true;
			   this.showCloneSnapshot = true;
			}
			else {
			   this.showSnapshotBtn = true;
			   this.showCloneSnapshot = false; 
			} */
			//refreshApex(this.records);
		})
		.catch(error=>{
			console.log(error);
			this.message = error.body.pageErrors[0].statusCode + '- '+ error.body.pageErrors[0].message;
		});
	 }
 handleCloneActions(event) {
		 //this.selectedView = event.detail.value;
		 this.searchTerm = '';
		 let clonedRecId = '';
		 if(this.selectedDateView == undefined) {
			this.dispatchEvent(
				new ShowToastEvent({
					title: 'Error',
					message: 'Please select a date to clone',
					variant: 'error'
				})
			);
		 }
		 else {
			let selectedBtnValue = event.target.value;
			/* if(selectedBtnValue == 'EditSnapshot') {
				this.disableSnapRecord = false;
				this.showCloneSnapshot = false;
				this.showSnapshotBtn = false;
			} */
			if(selectedBtnValue == 'UpdateSnapshot'){
				this.value = '';
				saveSnapShotRecords({
					selectedDateRecord: this.selectedDateView,
					selectedRegion : this.selectedRegion
				}).then((result) => {
					this.isCloned = true;
					clonedRecId = result[0].Site_Risk_Snapshot_Date__c;
					this.records = result;
					this.value = result[0].Site_Risk_Snapshot_Date__c;
					this.selectedDateView = result[0].Site_Risk_Snapshot_Date__c;
					this.fieldMetaData = [...this.fieldMetaData];
					this.fetchSnapShotRecs(clonedRecId);
					//refreshApex(this.records);
					this.dispatchEvent(
						new ShowToastEvent({
							title: 'Success',
							message: 'A snapshot copy has been created successfully',
							variant: 'success'
						})
					);
				})
				.catch(error=>{
					console.log(error);
					this.message = error.body.pageErrors[0].statusCode + '- '+ error.body.pageErrors[0].message;
				});
			} 
		 }
		 //}
		 /*else if(this.selectedView == 'EditThisView') {
			 this.isCloned = true;
			 let newRecords = [];
			 for (let item in this.records) {
				 this.records[item].rowCls = this.records[item].Color__c + 'RowCls';
				 newRecords.push(this.records[item]);
			 }
			 this.records = newRecords;
			 for(let item in this.fieldMetaData){
				 if(this.fieldMetaData[item].Field_Name__c =='Site_Risk_Name__c'){
					 this.fieldMetaData[item].Field_Name__c = 'Site_Risk__c';
				 }
				 this.fieldMetaData[item].Field_Type__c = this.siteRiskMap.get(this.fieldMetaData[item].Field_Name__c);
			 }
		 }*/
		 /*console.log('metaaaa###'+JSON.stringify(this.fieldMetaData));
		 let newRecords = [];
		 this.records = this.actualRecords;
		 for (let item in this.records) {
			 newRecords.push(this.records[item]);
			 
		 }
		 this.records = newRecords;
 */
		 //refreshApex(this.actualRecords);
	 }
 
	fetchPrevNextSteps(event) {
		 console.log('Called from child');
	 }
 
 handleAutoSave(event) {
		 console.log('called after 5 secs idle');
		 this.updateRecord(event);
	 }
	 
	 refreshPage(event){
		 this.fetchRecords();
	 }
 
	fetchSnapShotRecs(clonedRecId) {
		 fetchSnapShotRecords({
			 dateRecId : clonedRecId
		 }).then((result) => {
			 this.records = result;
			 this.totalSnapshotRecords = this.records;
			 this.recordsForPagination = JSON.parse(JSON.stringify(this.records));
			 this.disableSnapRecord = false;
			 this.showCloneSnapshot = false;
			 this.showSnapshotBtn = false;
			 //refreshApex(this.records);
		 })
		 .catch(error=>{
			 console.log(error);
			 this.message = error.body.pageErrors[0].statusCode + '- '+ error.body.pageErrors[0].message;
		 });
	 }

	handleRemove(event){
		console.log('value from remove###'+event.detail);
		this.selectedDateView = undefined;
	}
	handleVendorSearch(event) {
		//this.totalSnapshotRecords = JSON.parse(this.totalSnapshotRecords);
		//this.totalSnapshotRecords = this.totalSnapshotRecords.filter((element) => element.SR_Region__c === this.selectedRegion);
		console.log('fullRecords###'+this.fullRecords.length+':::'+JSON.stringify(this.fullRecords));
		console.log('totalSnapshotRecords###'+this.totalSnapshotRecords.length+'::::'+JSON.stringify(this.totalSnapshotRecords));
		const resultMap = new Map();
		// Fill the map with result1 elements

	/* 	for(let i in this.fullRecords){
			this.resultMap.set(fullRecords[i]., this.kanbanSchemaList[i]);
        } */


		this.fullRecords.forEach((elem) => {
			resultMap.set(elem.Id, elem);
		});
		console.log('Result======'+JSON.stringify([...resultMap.entries()]));
		
		// Update the map values
		this.totalSnapshotRecords.forEach((elem) => {
			if (resultMap.has(elem.Id)) {
				resultMap.set(elem.Id, elem);
			}
		});
		console.log('Result after======'+JSON.stringify([...resultMap.entries()]));
		
		this.fullRecords = Array.from(resultMap.values());
		console.log('safter update###'+JSON.stringify(this.fullRecords));
		if(this.searchTerm!=null && this.searchTerm!=undefined && this.searchTerm!=''){
			let searchRecords = [];
			for (let item in this.fullRecords) {
				let vendorName = this.fullRecords[item].SR_Vendor_Name__c;
				if(vendorName != null && vendorName != '' && vendorName != undefined) {
					if(vendorName.toUpperCase().includes(this.searchTerm.toUpperCase())) {
						searchRecords.push(this.fullRecords[item]);
					}
				}	
			}
			this.records = searchRecords;
		}else{
			this.records = this.fullRecords;
		}
	
	}
 }