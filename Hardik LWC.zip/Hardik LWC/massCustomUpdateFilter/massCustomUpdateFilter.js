import { LightningElement, api, track } from "lwc";

export default class MassCustomUpdateFilter extends LightningElement {
	@api filterLogic = "";
	@api appliedFilters;
	@track showAddFilterLogicButton;
	@track showAddFilterLogicInput = false;
	@track showButtonPanel = false;
	@track filterListInitial = [];
	@api filterListApi = [];
	@track filterList = [];
	@track isLoading = false;

	get showUnsavedFilterText() {
		return this.unSavedFilters.length > 0 ? true : false;
	}
	get savedFilters() {
		return this.filterList.filter((element) => {
			return element.isSaved;
		});
	}

	get unSavedFilters() {
		return this.filterList.filter((element) => {
			return !element.isSaved;
		});
	}


	connectedCallback() {
	if(this.filterListApi != undefined){
		for(let item in this.filterListApi){
			//this.filterList.push(this.filterListApi[item]);
		}
		
	}
	console.log('-------1--------------');
		if (this.appliedFilters ) {
			console.log('----------2----------------');
			this.filterLogic = this.appliedFilters.filterLogic;
			console.log('----------------3------',this.appliedFilters);
			this.appliedFilters.filterList.forEach((element, i) => {
				console.log('------------------------------4---------------------------------------------------');
				let filterRecord = { isSaved: true, filterValue: element.filterValue, index: i };
				console.log('filtreRecord',filterRecord);
				this.filterList.push(filterRecord);
				console.log('-------5-------');
			});
		}
		console.log('-----6----');
		this.filterListInitial = this.filterList;
		this.checkToShowAddFilterLogic();
	}

	checkToShowAddFilterLogic() {
		if (this.filterList && this.filterList.length > 1) {
			this.showAddFilterLogicButton = true;
		} else {
			this.showAddFilterLogicButton = false;
			this.showAddFilterLogicInput = false;
		}
		if (this.filterLogic) {
			this.showAddFilterLogicButton = false;
			this.showAddFilterLogicInput = true;
		}
	}

	handleFilterLogicChange(event) {
		this.filterLogic = event.detail.value;
		this.showButtonPanel = true;
	}

	triggerShowAddFilterLogicInput(event) {
		this.showAddFilterLogicButton = false;
		this.showAddFilterLogicInput = true;
	}

	triggerHideAddFilterLogicInput(event) {
		this.showAddFilterLogicInput = false;
		this.filterLogic = "";
		this.checkToShowAddFilterLogic();
		this.handleSave();
	}

	showAddNewFilterPopup(event) {
		const selectedEvent = new CustomEvent("addnewfiltervalue", {});
		this.dispatchEvent(selectedEvent);
	}

	showEditFilterPopup(event) {
		let selectedFilterIndex = parseInt(event.currentTarget.dataset.item);
		let valueToSend = this.filterList[selectedFilterIndex];
		const selectedEvent = new CustomEvent("editfiltervalue", {
			detail: valueToSend
		});
		this.dispatchEvent(selectedEvent);
	}

	@api
	updateFilterLists(value) {
		this.isLoading = true;
		let tempFilterListUpdate = JSON.parse(JSON.stringify(this.filterList));
		if (parseInt(value.index) == -1) {
			tempFilterListUpdate = [...tempFilterListUpdate, value];
		} else {
			tempFilterListUpdate.splice(parseInt(value.index), 1, value);
		}
		this.filterList = tempFilterListUpdate;
		this.updateIndexValuesInFilterList();
		this.checkToShowAddFilterLogic();
		this.showButtonPanel = true;
		this.isLoading = false;
	}

	updateIndexValuesInFilterList() {
		this.showButtonPanel = true;
		if (this.filterList) {
			let filterItems = JSON.parse(JSON.stringify(this.filterList));
			filterItems.forEach((element, i) => {
				console.log('==ele==='+JSON.stringify(element));
				element.index = i;
				i++;
			});
			console.log('==fiter==='+JSON.stringify(filterItems));
			this.filterList = filterItems;
		}

		console.log('==red==='+JSON.stringify(this.filterList));
	}

	handleSave(event) {
		this.isLoading = true;
		if (!this.isValidFilterLogic()) {
			this.isLoading = false;
			return;
		}
		let filterListToSend = [];
		let tempFilterList = JSON.parse(JSON.stringify(this.filterList));
		tempFilterList.forEach((element) => {
			console.log('fVal##'+JSON.stringify(element.filterValue));
			element.isSaved = true;
			filterListToSend.push(element.filterValue);
		});
		this.filterListInitial = tempFilterList;
		this.showButtonPanel = false;
		console.log('fVal123##'+this.filterLogic);
		let filterReturnValue = { filterLogic: this.filterLogic, filterList: filterListToSend , filterListValues :this.filterList };
		console.log('fVal4566##'+JSON.stringify(this.filterReturnValue));
		const selectedEvent = new CustomEvent("applyfilter", {
			detail: filterReturnValue
		});
		this.dispatchEvent(selectedEvent);
		this.isLoading = false;
	}

	isValidFilterLogic() {
		if (!this.filterLogic || !this.filterLogic.trim()) {
			return true;
		}
		const element = this.template.querySelector('[data-id="filterLogic"]');
		let tempString = this.filterLogic;
		tempString = tempString.replaceAll("AND", "&&").replaceAll("OR", "||");
		try {
			eval(tempString);
		} catch (error) {
			element.setCustomValidity("Check the spelling in your filter logic.");
			element.reportValidity();
			return false;
		}
		element.setCustomValidity("");
		element.reportValidity();
		return true;
	}

	removeAllFilters(event) {
		this.filterList = [];
		this.filterLogic = "";
		this.showAddFilterLogicButton = false;
		this.showAddFilterLogicInput = false;
		this.handleSave();
	}

	handleCancel(event) {
		this.filterList = this.filterListInitial;
		this.showButtonPanel = false;
	}
	@api
	deleteSelectedFilterRecord(value) {
		
		this.isLoading = true;		
		let tempfilterList = JSON.parse(JSON.stringify(this.filterList));
		tempfilterList.splice(parseInt(value.index), 1);
		this.filterList = tempfilterList;
		this.updateIndexValuesInFilterList();
		this.isLoading = false;
	}
}