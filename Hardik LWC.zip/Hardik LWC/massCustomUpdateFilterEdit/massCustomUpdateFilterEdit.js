import { LightningElement, api, track } from "lwc";
import { loadStyle } from "lightning/platformResourceLoader";
import minDPstyle from "@salesforce/resourceUrl/customMinifiedDatePicker";
const APPLICABLE_OPERATORS = [
	"equals",
	"not equal to",
	"less than",
	"greater than",
	"less or equal",
	"greater or equal",
	"contains",
	"does not contain",
	"start with"
];
export default class MassCustomUpdateFilterEdit extends LightningElement {
	@api availableFields;
	@api objectName;
	@track fieldsToFilter = [];
	@track operators = [];
	@track filterValue;
	@track selectedField;
	@track selectedOperator;
	@track blockClass;
	@track isSaved;
	@track index;
	@track isChanged = false;
	@track isDate = false;
	@track isNumber = false;
	@track isText = true;
	@track isTextarea = false;
	@track isPicklist = false;
	@track isMultiPicklist = false;
	@track isLoading = false;

	get showDeleteButton() {
		return this.index != -1;
	}

	get showCancelButton() {
		return this.index === -1;
	}

	connectedCallback() {
		this.blockClass = "slds-hide slds-p-around_medium";
		APPLICABLE_OPERATORS.forEach((element) => {
			this.operators.push({ label: element, value: element });
		});
		if (this.availableFields) {
			this.availableFields.forEach((element) => {
				if (element.Is_Active__c) {
					this.fieldsToFilter.push({ label: element.Field_Label__c, value: element.Field_Name__c });
				}
			});
		}
	}

	renderedCallback() {
		Promise.all([loadStyle(this, minDPstyle)]);
	}

	handleDoneClick(event) {
		this.isLoading = true;
		if (!this.isChanged) {
			this.blockClass = "slds-hide slds-p-around_medium";
			const updateCreateFilterEvent = new CustomEvent("cancelfilteredit", {});
			this.dispatchEvent(updateCreateFilterEvent);
			this.isLoading = false;
			return;
		}
		const areInputsCorrect = [...this.template.querySelectorAll("lightning-combobox")].reduce(
			(validSoFar, inputField) => {
				inputField.reportValidity();
				return validSoFar && inputField.checkValidity();
			},
			true
		);
		if (!areInputsCorrect) {
			this.isLoading = false;
			return;
		}
		let newFilter = {
			filterField: this.selectedField,
			operator: this.selectedOperator,
			valueToFilter: this.filterValue,
			filterFieldLabel: this.fieldsToFilter.find((opt) => opt.value === this.selectedField)
				? this.fieldsToFilter.find((opt) => opt.value === this.selectedField).label
				: ""
		};
		let valueToSend = { index: this.index, filterValue: newFilter, isSaved: this.isSaved };
		const updateCreateFilterEvent = new CustomEvent("updatefiltervalue", {
			detail: valueToSend
		});
		this.dispatchEvent(updateCreateFilterEvent);
		this.isChanged = false;
		this.blockClass = "slds-hide slds-p-around_medium";
		this.isLoading = false;
	}

	handleCancelClick(event) {
		this.isLoading = true;
		this.isChanged = false;
		this.blockClass = "slds-hide slds-p-around_medium";
		const updateCreateFilterEvent = new CustomEvent("cancelfilteredit", {});
		this.dispatchEvent(updateCreateFilterEvent);
		this.isLoading = false;
	}

	handleDeleteClick(event) {
		this.isLoading = true;
		let newFilter = {
			filterField: this.selectedField,
			operator: this.selectedOperator,
			valueToFilter: this.filterValue,
			filterFieldLabel: this.fieldsToFilter.find((opt) => opt.value === this.selectedField)
				? this.fieldsToFilter.find((opt) => opt.value === this.selectedField).label
				: ""
		};
		let valueToSend = { index: this.index, filterValue: newFilter, isSaved: this.isSaved };
		const updateCreateFilterEvent = new CustomEvent("deletefiltervalue", {
			detail: valueToSend
		});
		this.dispatchEvent(updateCreateFilterEvent);
		this.isChanged = false;
		this.blockClass = "slds-hide slds-p-around_medium";
		this.isLoading = false;
	}

	handleFieldChange(event) {
		this.selectedField = event.detail.value;
		if (!this.isChanged) {
			this.isChanged = true;
		}
		this.setFieldType();
	}

	handleOperatorChange(event) {
		this.selectedOperator = event.detail.value;
		if (!this.isChanged) {
			this.isChanged = true;
		}
	}

	handleFilterValueChange(event) {
		if (!this.isChanged) {
			this.isChanged = true;
		}
		if (this.isPicklist) {
			this.filterValue = event.detail.selectedValue;
		} else {
			this.filterValue = event.detail.value;
		}
	}

	@api
	updateFilterEditSelection(value) {
		this.isSaved = value.isSaved;
		this.index = value.index;
		let filterRecordValue = value.filterValue;
		if (filterRecordValue) {
			this.selectedOperator = filterRecordValue.operator;
			this.filterValue = filterRecordValue.valueToFilter;
			this.selectedField = filterRecordValue.filterField;
		}
		this.setFieldType();
		this.blockClass = "slds-show slds-p-around_medium";
	}

	setFieldType() {
		let selectedFieldObject = this.availableFields.find((opt) => opt.Field_Name__c === this.selectedField);
		if (!selectedFieldObject) {
			return;
		}
		if (selectedFieldObject.Field_Type__c === "Date") {
			this.isPicklist = false;
			this.isDate = true;
			this.isNumber = false;
			this.isTextarea = false;
			this.isText = false;
			this.isMultiPicklist = false;
		} else if (selectedFieldObject.Field_Type__c === "Number") {
			this.isPicklist = false;
			this.isDate = false;
			this.isNumber = true;
			this.isTextarea = false;
			this.isText = false;
			this.isMultiPicklist = false;
		} else if (selectedFieldObject.Field_Type__c === "Text Area") {
			this.isPicklist = false;
			this.isDate = false;
			this.isNumber = false;
			this.isTextarea = true;
			this.isText = false;
			this.isMultiPicklist = false;
		} else if (selectedFieldObject.Field_Type__c === "Picklist") {
			if (this.isPicklist) {
				this.template.querySelector("c-picklist").refreshPicklistOptions(this.selectedField);
				return;
			}
			this.isPicklist = true;
			this.isDate = false;
			this.isNumber = false;
			this.isTextarea = false;
			this.isText = false;
			this.isMultiPicklist = false;
		} else if (selectedFieldObject.Field_Type__c === "Multi Select") {
			if (this.isMultiPicklist) {
				this.template.querySelector("c-select-component").updateFieldNameFromParent(this.selectedField);
				return;
			}
			this.isPicklist = false;
			this.isDate = false;
			this.isNumber = false;
			this.isTextarea = false;
			this.isText = false;
			this.isMultiPicklist = true;
		} else {
			this.isDate = false;
			this.isNumber = false;
			this.isTextarea = false;
			this.isPicklist = false;
			this.isText = true;
			this.isMultiPicklist = false;
		}
	}
}