/* eslint-disable no-console */
import { LightningElement, track, wire, api } from "lwc";
import { getPicklistValuesByRecordType } from "lightning/uiObjectInfoApi";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import { CurrentPageReference } from "lightning/navigation";
import { fireEvent } from "c/pubsub";

export default class Picklist extends LightningElement {
	@wire(CurrentPageReference) pageRef;

	@api objectApiName;
	@api pickListfieldApiName;
	@api label;
	@api variant;
	@api isdisabled;

	@api uniqueKey;

	@track value;
	recordTypeIdValue;

	@track options = [
		{ label: "--None--", value: "" }
	];

	@api
	get recordTypeId() {
		return this.recordTypeIdValue;
	}
	set recordTypeId(value) {
		this.recordTypeIdValue = value;
	}

	get picklistoptions() {
		return this.options;
	}
	/* added by skv to get picklist options from parent instead of querying in each child */
	@api set picklistoptions(value) {
		if (value) {
			if (
				(!this.recordTypeIdValue || this.recordTypeIdValue === value.rTypeId) &&
				value.picklistFields[this.pickListfieldApiName] !== undefined
			) {
				this.recordTypeIdValue = undefined;
				this.objectApiName = undefined;
				let tempOptions = [{ label: "--None--", value: "" }];
				let temp2Options = value.picklistFields[this.pickListfieldApiName].values;
				temp2Options.forEach((opt) => tempOptions.push(opt));
				this.options = tempOptions;
				if (this.selectedValue === "" || this.selectedValue === undefined || this.selectedValue === null) {
					this.value = { label: "--None--", value: "" }.value;
				} else  {                    
					console.log('2');                    
					let  val  =  this.options.find((listItem)  => listItem  !==  undefined  &&   listItem.value  ===  this.selectedValue);                
					console.log('wiredOptions val' , val);                
					this.value  =  val  !==  undefined  ?  val.value  :  '';     
				}
			}
		}
	}
	

	@api
	get selectedValue() {
		return this.value;
	}
	set selectedValue(val) {
		if (val === "" || val === undefined || val === null) this.value = { label: "--None--", value: "" }.value;
		else this.value = val;
	}

	@wire(getObjectInfo, { objectApiName: "$objectApiName" })
	getRecordTypeId({ error, data }) {
		if (data) {
			this.record = data;
			this.error = undefined;
			if (this.recordTypeId === undefined) {
				this.recordTypeId = this.record.defaultRecordTypeId;
				if (this.record.defaultRecordTypeId === undefined) {
					if (this.record.picklistFieldValues[this.pickListfieldApiName] !== undefined) {
						let tempOptions = [{ label: "--None--", value: "" }];
						let temp2Options = this.record.picklistFieldValues[this.pickListfieldApiName].values;
						temp2Options.forEach((opt) => tempOptions.push(opt));
						this.options = tempOptions;
					}
					if (this.selectedValue === "" || this.selectedValue === undefined || this.selectedValue === null) {
						this.value = { label: "--None--", value: "" }.value;
					} else {
						this.value = this.options.find((listItem) => listItem.value === this.selectedValue).value;
					}
				}
			}
		} else if (error) {
			this.error = error;
			this.record = undefined;
		}
	}

	@wire(getPicklistValuesByRecordType, { recordTypeId: "$recordTypeId", objectApiName: "$objectApiName" })
	wiredOptions({ error, data }) {
		if (data) {
			console.log('data in picklist###'+JSON.stringify(this.data));
			this.record = data;
			this.error = undefined;
			let opn = [];

			if (this.selectedValue === "" || this.selectedValue === undefined || this.selectedValue === null) {
				opn.push({ label: "--None--", value: "" });
			} else {
				opn.push({ label: this.selectedValue, value: this.selectedValue });
			}

			if (this.record.picklistFieldValues[this.pickListfieldApiName] !== undefined) {
				let temp2Options = this.record.picklistFieldValues[this.pickListfieldApiName].values;
				temp2Options.forEach((element)=>{
					if(element.label !== this.selectedValue)
						opn.push({ label: element.label, value: element.value });
				})
				this.options = opn;
			}

		} else if (error) {
			this.error = error;
			this.record = undefined;
		}
	}

	/*
	@wire(getPicklistValuesByRecordType, { recordTypeId: "$recordTypeId", objectApiName: "$objectApiName" })
	wiredOptions({ error, data }) {
		if (data) {
			this.record = data;
			this.error = undefined;
			
			if (this.record.picklistFieldValues[this.pickListfieldApiName] !== undefined) {
				let tempOptions = [{ label: "--None--", value: "" }];
				let temp2Options = this.record.picklistFieldValues[this.pickListfieldApiName].values;
				temp2Options.forEach((opt) => tempOptions.push(opt));

				this.options = tempOptions;
			}
			console.log(this.options);

			if (this.selectedValue === "" || this.selectedValue === undefined || this.selectedValue === null) {
				this.value = { label: "--None--", value: "" }.value;
			} else {
				this.value = this.options.find((listItem) => listItem.value === this.selectedValue).value;
			}
		} else if (error) {
			this.error = error;
			this.record = undefined;
		}
	}
	*/
	connectedCallback() {
		console.log('recType###'+this.recordTypeId);
		console.log('objName###'+this.objectApiName);
	}
	@api
	refreshPicklistOptions(value) {
		this.pickListfieldApiName = value;
		if (this.record.picklistFieldValues[this.pickListfieldApiName] !== undefined) {
			let tempOptions = [{ label: "--None--", value: "" }];
			let temp2Options = this.record.picklistFieldValues[this.pickListfieldApiName].values;
			temp2Options.forEach((opt) => tempOptions.push(opt));

			this.options = tempOptions;
		}
		if (this.selectedValue === "" || this.selectedValue === undefined || this.selectedValue === null) {
			this.value = { label: "--None--", value: "" }.value;
		} else {
			this.value = this.options.find((listItem) => listItem.value === this.selectedValue).value;
		}
	}

	handleChange(event) {
		let tempValue = event.target.value;
		let selectedValue = tempValue;
		let key = this.uniqueKey;
         
		//Firing change event for aura container to handle
		//For Self
		const pickValueChangeEvent = new CustomEvent("picklistchange", {
			detail: { selectedValue, key }
		});
		 
		this.dispatchEvent(pickValueChangeEvent);
         
		//For dependent picklist
		let eventValues = { selValue: selectedValue, uniqueFieldKey: `${this.pickListfieldApiName}${this.uniqueKey}` };
		//Fire Pub/Sub Event, So that every other comp in the page knows the change
		fireEvent(this.pageRef, "controllingValue", eventValues);
	}
}